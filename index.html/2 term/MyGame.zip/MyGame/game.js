"use strict"

let cvs = document.querySelector('#canvas');
let ctx = cvs.getContext('2d');

// --- РАЗМЕР НА ВЕСЬ ЭКРАН ---
cvs.width = window.innerWidth;
cvs.height = window.innerHeight;

// --- КАРТИНКИ ---
let ship = new Image();
let enemyImg1 = new Image();
let enemyImg2 = new Image();
let enemyImg3 = new Image();
let bulletImg = new Image();
let bg = new Image();

ship.src = 'img/FL_ship.png';
enemyImg1.src = 'img/Alien_purple1.png';
enemyImg2.src = 'img/Alien_pink2.png';
enemyImg3.src = 'img/Alien_blue3.png';
bulletImg.src = 'img/Bullet.png';
bg.src = 'img/BG.png';

// --- ИГРОК ---
let xPos = cvs.width / 2 - 20;
let yPos = cvs.height - 80;

// --- ПУЛИ ---
let bullets = [];

// --- ВРАГИ ---
let enemies = [];
let wave = 1;

// --- СОЗДАНИЕ ВРАГОВ ---
function spawnEnemies(){
    enemies = [];
    for (let i = 0; i < 6 + wave; i++) {
        enemies.push({
            x: 60 + i * 80,
            y: 50,
            alive: true,
            type: Math.floor(Math.random() * 3)
        });
    }
}

spawnEnemies();

// --- СЧЁТ ---
let score = 0;
let gameOver = false;

// --- УПРАВЛЕНИЕ ---
document.addEventListener("keydown", function(e){

    if(gameOver) return;

    if(e.key == 'ArrowLeft'){
        xPos -= 25;
    }

    if(e.key == 'ArrowRight'){
        xPos += 25;
    }

    if(e.key == ' '){
        bullets.push({
            x: xPos + 18,
            y: yPos
        });
    }
});

// --- ИГРА ---
function draw(){

    ctx.clearRect(0, 0, cvs.width, cvs.height);

    // фон
    ctx.drawImage(bg, 0, 0, cvs.width, cvs.height);

    if(!gameOver){

        // --- ВРАГИ ---
        let aliveCount = 0;

        for(let i = 0; i < enemies.length; i++){
            if(enemies[i].alive){

                aliveCount++;

                let img;
                if(enemies[i].type == 0) img = enemyImg1;
                if(enemies[i].type == 1) img = enemyImg2;
                if(enemies[i].type == 2) img = enemyImg3;

                ctx.drawImage(img, enemies[i].x, enemies[i].y, 40, 40);

                enemies[i].y += 0.3 + wave * 0.1;

                // ПРОИГРЫШ
                if(enemies[i].y > cvs.height - 100){
                    gameOver = true;
                }
            }
        }

        // --- НОВАЯ ВОЛНА ---
        if(aliveCount == 0){
            wave++;
            spawnEnemies();
        }

        // --- ПУЛИ ---
        for(let i = 0; i < bullets.length; i++){
            bullets[i].y -= 7;

            ctx.drawImage(bulletImg, bullets[i].x, bullets[i].y, 4, 12);

            for(let j = 0; j < enemies.length; j++){
                if(enemies[j].alive &&
                   bullets[i].x < enemies[j].x + 40 &&
                   bullets[i].x + 4 > enemies[j].x &&
                   bullets[i].y < enemies[j].y + 40 &&
                   bullets[i].y + 12 > enemies[j].y){

                    enemies[j].alive = false;
                    bullets[i].y = -10;
                    score++;
                }
            }
        }

        // --- ИГРОК ---
        ctx.drawImage(ship, xPos, yPos, 40, 40);
    }

    // --- СЧЁТ ---
    ctx.fillStyle = "#fff";
    ctx.font = "20px Arial";
    ctx.fillText("Score: " + score, 20, 40);

    ctx.fillText("Wave: " + wave, 20, 70);

    // --- GAME OVER ---
    if(gameOver){
        ctx.fillStyle = "#fff";
        ctx.font = "50px Arial";
        ctx.fillText("GAME OVER", cvs.width/2 - 150, cvs.height/2);

        ctx.font = "20px Arial";
        ctx.fillText("Нажми F5 чтобы начать заново", cvs.width/2 - 140, cvs.height/2 + 40);
    }

    requestAnimationFrame(draw);
}

// --- ЗАПУСК ---
bg.onload = draw;